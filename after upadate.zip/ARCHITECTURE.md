# 🏗️ SMARTRESULT - ARCHITECTURE & TECH STACK

## System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         CLIENT LAYER                             │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────┐  │
│  │  Student Portal  │  │  Admin Login     │  │  Dashboard   │  │
│  │   index.html     │  │  admin-login.    │  │  admin-      │  │
│  │                  │  │  html            │  │  dashboard.  │  │
│  └────────┬─────────┘  └────────┬─────────┘  └──────┬───────┘  │
│           │                     │                   │           │
│  ┌────────▼──────────────────────▼───────────────────▼────────┐ │
│  │              JavaScript Layer (Public)                     │ │
│  │  ┌───────────────┐  ┌──────────────┐  ┌───────────────┐   │ │
│  │  │  app.js       │  │  admin-auth. │  │  admin-       │   │ │
│  │  │  (Search)     │  │  js (Login)  │  │  dashboard.js │   │ │
│  │  │               │  │              │  │  (Analytics)  │   │ │
│  │  └───────────────┘  └──────────────┘  └───────────────┘   │ │
│  └────────┬──────────────────────────────────────────────────┘ │
│           │                                                     │
│           └──────────────────────┬──────────────────────────────┤
│                              Bootstrap 5 CSS                    │
│                           Responsive Design                     │
└─────────────────────────────────────────────────────────────────┘
                                  │
         ┌────────────────────────┼────────────────────────┐
         │                        │                        │
    HTTP │                        │ HTTP                   │ HTTP
         │                        │                        │
         ▼                        ▼                        ▼
   ┌──────────────────────────────────────────────────────────────┐
   │                      API GATEWAY LAYER                        │
   │                   Express.js Server (Port 3000)              │
   │                                                              │
   │  ┌────────────────────────────────────────────────────────┐ │
   │  │              Middleware Stack                          │ │
   │  │  ┌──────────────┐  ┌──────────────┐  ┌────────────┐   │ │
   │  │  │   Helmet     │  │ Auth         │  │ Error      │   │ │
   │  │  │  (Security)  │  │ Middleware   │  │ Handler    │   │ │
   │  │  └──────────────┘  └──────────────┘  └────────────┘   │ │
   │  │  Rate Limiting │ CORS │ Body Parser                    │ │
   │  └────────────────────────────────────────────────────────┘ │
   │           │                                                  │
   │  ┌────────▼──────────────────────────────────────────────┐   │
   │  │              Routes Layer (v1.js)                      │   │
   │  │  /api/v1/auth/*        /api/v1/admin/*                │   │
   │  │  /api/v1/result/*      /health                        │   │
   │  └────────┬──────────────────────────────────────────────┘   │
   │           │                                                  │
   │  ┌────────▼──────────────────────────────────────────────┐   │
   │  │            Controllers Layer                          │   │
   │  │  ┌──────────────┐  ┌──────────────┐  ┌────────────┐  │   │
   │  │  │    Auth      │  │   Result     │  │ Dashboard  │  │   │
   │  │  │ Controller   │  │ Controller   │  │ Controller │  │   │
   │  │  │              │  │              │  │            │  │   │
   │  │  │ • Register   │  │ • Search     │  │ • Stats    │  │   │
   │  │  │ • Login      │  │ • Store      │  │ • Charts   │  │   │
   │  │  │ • Profile    │  │ • Download   │  │ • History  │  │   │
   │  │  │ • Logout     │  │ • Paginate   │  │ • Cleanup  │  │   │
   │  │  └──────────────┘  └──────────────┘  └────────────┘  │   │
   │  └────────┬──────────────────────────────────────────────┘   │
   │           │                                                  │
   │  ┌────────▼──────────────────────────────────────────────┐   │
   │  │         Utilities & Services Layer                     │   │
   │  │  ┌──────────────┐  ┌──────────────┐  ┌────────────┐  │   │
   │  │  │   JWT        │  │   PDF        │  │ Scraper    │  │   │
   │  │  │  Helpers     │  │  Generator   │  │ Service    │  │   │
   │  │  │              │  │              │  │            │  │   │
   │  │  │ • Generate   │  │ • Create     │  │ • Fetch    │  │   │
   │  │  │ • Verify     │  │ • Stream     │  │ • Parse    │  │   │
   │  │  │ • Decode     │  │ • Tables     │  │ • Extract  │  │   │
   │  │  └──────────────┘  └──────────────┘  └────────────┘  │   │
   │  │                                                        │   │
   │  │  Parser Service │ Error Helpers │ Validators         │   │
   │  └────────┬─────────────────────────────────────────────┘   │
   │           │                                                  │
   └───────────┼──────────────────────────────────────────────────┘
               │
    ┌──────────┴─────────────────────┬─────────────────────┐
    │                                │                     │
    ▼                                ▼                     ▼
┌─────────────────────┐   ┌────────────────────┐   ┌─────────────┐
│   MONGODB DATABASE  │   │  Authentication    │   │  File System│
│                     │   │  & Security        │   │             │
│  ┌───────────────┐  │   │  ┌──────────────┐  │   │  ┌────────┐ │
│  │ Admin Schema  │  │   │  │ Bcrypt Hash  │  │   │  │ PDFs   │ │
│  │               │  │   │  │ Generation   │  │   │  │ Temp   │ │
│  │ • Credentials │  │   │  │              │  │   │  │ Files  │ │
│  │ • Role/Access │  │   │  │ JWT Secret   │  │   │  │        │ │
│  │ • Timestamps  │  │   │  │ Management   │  │   │  │ Cache  │ │
│  └───────────────┘  │   │  └──────────────┘  │   │  └────────┘ │
│                     │   │                     │   │             │
│  ┌───────────────┐  │   └─────────────────────┘   └─────────────┘
│  │ Result Schema │  │
│  │               │  │      Running on:
│  │ • Pin (Index) │  │      • Mongoose 9.2.1 (ODM)
│  │ • Data        │  │      • bcryptjs 2.4.3
│  │ • CGPA/SGPA   │  │      • jsonwebtoken 9.1.2
│  │ • Metadata    │  │      • PDFKit 0.13.0
│  │ • Indexed For │  │
│  │   Fast Query  │  │
│  └───────────────┘  │
│                     │
│  Indexes on:        │
│  • pin field        │
│  • studentName      │
│  • Text search      │
│                     │
│  MongoDB 7.0+       │
└─────────────────────┘
```

---

## 📊 Data Flow Diagrams

### Student Search Flow

```
┌──────────────────┐
│  User enters PIN │
│  at index.html   │
└────────┬─────────┘
         │
         ▼
┌──────────────────────────┐
│ app.js validates input   │
│ Shows loading modal       │
└────────┬─────────────────┘
         │
         ▼ Fetch POST
┌────────────────────────────┐
│ /api/v1/result             │
│ resultController.getResult │
└────────┬───────────────────┘
         │
         ▼
┌─────────────────────────────┐
│ scraperService.scrapeResult │
│ (Puppeteer)                  │
└────────┬────────────────────┘
         │
         ▼
┌────────────────────────────────────┐
│ Parse & Extract Data               │
│ Calculate CGPA/SGPA                │
└────────┬─────────────────────────┤
         │
         ▼
┌──────────────────────────────────────┐
│ Store in MongoDB (Result.js)         │
│ • Create or update record            │
│ • Add metadata (IP, timestamp)       │
│ • Auto-calculate aggregates          │
└────────┬───────────────────────────┘
         │
         ▼
┌──────────────────────────┐
│ Return JSON Response     │
│ + 200 OK                 │
└────────┬─────────────────┘
         │
         ▼
┌──────────────────────────────────┐
│ app.js renders result            │
│ • Display semesters               │
│ • Show grades                     │
│ • Calculate totals                │
│ • Hide loading modal              │
└──────────────────────────────────┘
```

### Admin Authentication Flow

```
┌─────────────────────────┐
│ User visits admin-login │
│ Enters credentials      │
└────────┬────────────────┘
         │
         ▼
┌─────────────────────────────────────┐
│ admin-auth.js                       │
│ Validates input (client-side)       │
└────────┬────────────────────────────┘
         │
         ▼ Fetch POST
┌────────────────────────────────────┐
│ /api/v1/auth/login (or register)   │
│ authController.loginAdmin           │
└────────┬───────────────────────────┘
         │
         ▼
┌──────────────────────────────────┐
│ Check MongoDB Admin collection   │
│ Find user by username            │
└────────┬───────────────────────┤
         │
         ├─ User Not Found ──┐
         │                   │ Return 401
         │                   ▼
         │          Error: Invalid credentials
         │
         ├─ User Found ──┐
         │               ▼
         │     ┌────────────────────────────┐
         │     │ Verify password with bcrypt│
         │     │ comparePassword()           │
         │     └────────┬───────────────────┘
         │              │
         │         ┌────┴────┐
         │         │ Match? │
         │    No   │        │  Yes
         │         ▼        ▼
         │      401    ┌─────────────────────┐
         │            │ Generate JWT Token  │
         │            │ • AdminID           │
         │            │ • Username          │
         │            │ • 7 day expiry      │
         │            └────────┬────────────┘
         │                     │
         ▼                     ▼
    Error          ┌──────────────────────────┐
                   │ Update lastLogin field   │
                   │ Save to database         │
                   └────────┬─────────────────┘
                            │
                            ▼
                   ┌─────────────────────┐
                   │ Return JWT to client│
                   │ { token: "..." }    │
                   └────────┬────────────┘
                            │
                            ▼
                   ┌──────────────────────────┐
                   │ admin-auth.js storesJWT │
                   │ in localStorage          │
                   └────────┬─────────────────┘
                            │
                            ▼
                   ┌──────────────────────────┐
                   │ Redirect to dashboard    │
                   │ admin-dashboard.html     │
                   └──────────────────────────┘
```

### Protected Route Access Flow

```
┌─────────────────────────────┐
│ User clicks "Get Stats"      │
│ (Protected API call)         │
└────────┬────────────────────┘
         │
         ▼
┌────────────────────────────────────────┐
│ admin-dashboard.js                      │
│ Retrieves JWT from localStorage         │
│ Adds to Authorization header:           │
│ "Bearer eyJhbGciOiJIUzI1NiIs..."       │
└────────┬───────────────────────────────┘
         │
         ▼ Fetch GET
┌────────────────────────────────────────┐
│ /api/v1/admin/dashboard                │
│ (With Authorization header)            │
└────────┬───────────────────────────────┘
         │
         ▼
┌────────────────────────────────────────┐
│ Express receives request               │
│ middleware/auth.js (authenticateAdmin) │
└────────┬───────────────────────────────┘
         │
         ▼
┌────────────────────────────────────────┐
│ Extract token from Authorization hdr  │
│ Verify with JWT_SECRET                │
└────────┬───────────────────────────────┘
         │
    ┌────┴──────┐
    │ Valid?    │
No  │           │ Yes
    ▼           ▼
┌────────┐   ┌─────────────────────────┐
│ Return │   │ Decode token details    │
│ 401    │   │ Attach to req.admin     │
└────────┘   │ Call next middleware    │
             └────────┬────────────────┘
                      │
                      ▼
             ┌──────────────────────────┐
             │ Controller receives req  │
             │ with req.admin populated │
             │ Queries database         │
             └────────┬─────────────────┘
                      │
                      ▼
             ┌──────────────────────────┐
             │ Calculate aggregates     │
             │ Return JSON response     │
             │ { stats: {...} }        │
             └────────┬─────────────────┘
                      │
                      ▼
             ┌──────────────────────────┐
             │ admin-dashboard.js       │
             │ renders chart & stats    │
             └──────────────────────────┘
```

---

## 💾 Database Schema Relationships

```
┌─────────────────────────────────┐
│       Admin Collection          │
├─────────────────────────────────┤
│ _id: ObjectId (Primary Key)     │
│ username: String (Unique)       │
│ email: String (Unique)          │
│ password: String (Hashed)       │
│ role: "admin" | "super-admin"   │
│ isActive: Boolean               │
│ lastLogin: Date                 │
│ createdAt: Date                 │
│ updatedAt: Date                 │
└────────────┬────────────────────┘
             │ References (1:Many)
             │
             ▼
┌────────────────────────────────────────────┐
│         Result Collection                   │
├────────────────────────────────────────────┤
│ _id: ObjectId (Primary Key)                │
│ pin: String (Indexed)                      │
│ studentName: String (Indexed)              │
│ rollNumber: String                         │
│ semesters: [{                              │
│   semester: Number                         │
│   subjects: [{                             │
│     code, name, credits, grade, points    │
│   }]                                       │
│   sgpa: Number                             │
│ }]                                         │
│ overallCGPA: Number                        │
│ searchedBy: ObjectId (FK to Admin)         │◄──┘
│ ipAddress: String (Audit)                  │
│ scrapedAt: Date                            │
│ raw: Object (Original data)                │
│ createdAt: Date                            │
│ updatedAt: Date                            │
└────────────────────────────────────────────┘

Indexes:
├─ pin: 1
├─ studentName: 1
└─ "studentName": text, "semesters.subjects.name": text
```

---

## 🔐 Security Architecture

```
┌────────────────────────────────────────────────┐
│              Security Layers                    │
├────────────────────────────────────────────────┤
│                                                │
│  Layer 1: NETWORK SECURITY (Helmet)           │
│  ├─ Strict-Transport-Security (HSTS)          │
│  ├─ X-Frame-Options: DENY                     │
│  ├─ X-Content-Type-Options: nosniff           │
│  ├─ Content-Security-Policy                   │
│  └─ 10+ additional security headers           │
│                                                │
│  Layer 2: RATE LIMITING & THROTTLING          │
│  ├─ 30 requests per minute per IP             │
│  ├─ Applied to all /api/ routes                │
│  └─ Prevents brute force attacks              │
│                                                │
│  Layer 3: INPUT VALIDATION                    │
│  ├─ express-validator on all inputs           │
│  ├─ Whitelist allowed characters              │
│  ├─ Length checks                             │
│  └─ Type verification                         │
│                                                │
│  Layer 4: AUTHENTICATION                      │
│  ├─ Bcrypt password hashing (10 rounds)       │
│  ├─ JWT tokens with 7-day expiry              │
│  ├─ Bearer token in Authorization header      │
│  └─ Token verification on protected routes    │
│                                                │
│  Layer 5: ERROR HANDLING                      │
│  ├─ No stack traces in production             │
│  ├─ Generic error messages to client          │
│  ├─ Detailed logging for administrators       │
│  └─ Centralized error middleware              │
│                                                │
│  Layer 6: DATABASE SECURITY                   │
│  ├─ Mongoose schema validation                │
│  ├─ SQL injection prevention (no SQL)         │
│  ├─ Connection pooling                        │
│  └─ Environment variable secrets              │
│                                                │
└────────────────────────────────────────────────┘
```

---

## 📈 Performance Architecture

```
┌──────────────────────────────────┐
│     Performance Optimization     │
├──────────────────────────────────┤
│                                  │
│ Database Optimization:           │
│ ├─ Indexed fields (pin, name)   │
│ ├─ Text indexes for search      │
│ ├─ Query projection (select)    │
│ ├─ Aggregation pipelines        │
│ └─ Connection pooling           │
│                                  │
│ Query Optimization:              │
│ ├─ Cursor.limit(10)             │
│ ├─ Cursor.skip(page * 10)       │
│ ├─ Only needed fields in SELECT │
│ ├─ Lean queries for read-only   │
│ └─ Batch processing             │
│                                  │
│ Caching Strategy:                │
│ ├─ Results stored after scrape  │
│ ├─ No duplicate API calls       │
│ ├─ Browser caching enabled      │
│ └─ CDN-ready structure           │
│                                  │
│ Frontend Optimization:           │
│ ├─ Bootstrap CDN delivery       │
│ ├─ Minified CSS/JS (production) │
│ ├─ Lazy loading of data         │
│ ├─ Async API calls              │
│ └─ Event debouncing             │
│                                  │
│ Scalability Features:            │
│ ├─ Stateless server design      │
│ ├─ Horizontal scaling ready     │
│ ├─ Load balancer compatible     │
│ ├─ Database replication support │
│ └─ Container-based deployment   │
│                                  │
└──────────────────────────────────┘
```

---

## 🚀 Deployment Architecture

```
┌──────────────────────────────────────────────────────┐
│          Production Deployment Options                │
├──────────────────────────────────────────────────────┤
│                                                      │
│  Option 1: DOCKER (Local/Staging)                   │
│  ┌────────────────────────────────────────────────┐ │
│  │ docker-compose.yml                            │ │
│  │ ├─ App Service (Node 18 Alpine)              │ │
│  │ ├─ MongoDB Service (v7.0)                    │ │
│  │ ├─ Shared Network                             │ │
│  │ └─ Volume Mounts                              │ │
│  └────────────────────────────────────────────────┘ │
│                                                      │
│  Option 2: RENDER / RAILWAY (PaaS)                  │
│  ┌────────────────────────────────────────────────┐ │
│  │ GitHub Integration                             │ │
│  │ ├─ Auto-deploy on push                        │ │
│  │ ├─ Environment variables                      │ │
│  │ ├─ Managed MongoDB Atlas                      │ │
│  │ ├─ SSL/TLS auto-configured                    │ │
│  │ └─ Health checks enabled                      │ │
│  └────────────────────────────────────────────────┘ │
│                                                      │
│  Option 3: HEROKU (Classic)                         │
│  ┌────────────────────────────────────────────────┐ │
│  │ Procfile: web: node server.js                 │ │
│  │ ├─ Git push deployment                        │ │
│  │ ├─ Dyno management                            │ │
│  │ ├─ Add-ons (MongoDB)                          │ │
│  │ └─ Scaling options                            │ │
│  └────────────────────────────────────────────────┘ │
│                                                      │
│  Option 4: AWS/AZURE (IaaS)                         │
│  ┌────────────────────────────────────────────────┐ │
│  │ EC2 / App Service                              │ │
│  │ ├─ Full control                                │ │
│  │ ├─ RDS / Cosmos for database                  │ │
│  │ ├─ Load balancing                              │ │
│  │ └─ Auto-scaling groups                         │ │
│  └────────────────────────────────────────────────┘ │
│                                                      │
└──────────────────────────────────────────────────────┘
```

---

## 🔄 Request/Response Flow

```
CLIENT REQUEST
    │
    ├─ Method: GET/POST/PUT/DELETE
    ├─ Headers: Authorization, Content-Type
    ├─ Body: JSON payload
    └─ URL: /api/v1/endpoint
         │
         ▼
EXPRESS MIDDLEWARE (Order matters!)
    │
    ├─ 1. express.json() ─────┐
    ├─ 2. cors() ──────────────┤
    ├─ 3. helmet() ────────────┼─→ Security Processing
    ├─ 4. rateLimit() ─────────┤
    ├─ 5. body validators ─────┘
    │
    ├─ 6. Router matching ─────→ Find matching route
    │                           (/api/v1/result/:id)
    │
    ├─ 7. Auth middleware ─────→ Verify JWT token
    │    (if protected route)    (check req.admin)
    │
    └─ 8. Controller ──────────→ Business logic
         │                      Call models/services
         │
         ▼
DATABASE OPERATION (Mongoose)
    │
    ├─ Query: db.collection.find()
    ├─ Validation: Check schema
    ├─ Processing: Aggregation/calculation
    ├─ Response: Return document(s)
    │
    └─ Error: Catch & throw
         │
         ▼
ERROR HANDLER (if error)
    │
    ├─ Catch error
    ├─ Determine type
    ├─ Format message
    └─ Set HTTP status
         │
         ▼
SERVER RESPONSE (JSON)
    │
    ├─ Status: 200/201/400/401/500
    ├─ Headers: Content-Type: application/json
    ├─ Body: {"data": {...}} or {"error": "..."}
    │
    └─ Send to CLIENT
         │
         ▼
CLIENT HANDLING
    │
    ├─ JavaScript receives response
    ├─ Check status code
    ├─ Parse JSON
    ├─ Update DOM
    └─ Show success/error message
```

---

## 📋 Component Communication Matrix

```
┌─────────────┬──────────────┬──────────────┬──────────────┐
│  Component  │ Communicates │    Using     │   Protocol   │
├─────────────┼──────────────┼──────────────┼──────────────┤
│ HTML (UI)   │ JavaScript   │  DOM Events  │   DOM API    │
├─────────────┼──────────────┼──────────────┼──────────────┤
│ JavaScript  │ Express API  │ Fetch API    │   HTTP/REST  │
├─────────────┼──────────────┼──────────────┼──────────────┤
│ Express     │ Controllers  │ Direct call  │  JavaScript  │
├─────────────┼──────────────┼──────────────┼──────────────┤
│ Controllers │ Models       │ Mongoose     │  JavaScript  │
├─────────────┼──────────────┼──────────────┼──────────────┤
│ Models      │ MongoDB      │  Mongoose    │   ODM API    │
├─────────────┼──────────────┼──────────────┼──────────────┤
│ Services    │ External API │  Puppeteer   │  Automation  │
├─────────────┼──────────────┼──────────────┼──────────────┤
│ Utils       │ All layers   │ Direct call  │  Functions   │
└─────────────┴──────────────┴──────────────┴──────────────┘
```

---

## 🎯 Technology Stack Decision Tree

```
Need to:                           → Use:
─────────────────────────────────────────────────
Handle HTTP requests              → Express.js
Serve static files                → express.static()
Query database                    → Mongoose + MongoDB
Hash passwords                    → bcryptjs
Generate tokens                   → jsonwebtoken
Validate input                    → express-validator
Protect headers                   → helmet
Rate limit requests               → express-rate-limit
Create PDFs                       → PDFKit
Style frontend                    → Bootstrap 5 + CSS3
Fetch from JavaScript             → Fetch API / async-await
Scrape websites                   → Puppeteer
Run scheduler tasks               → node-scheduler (future)
Log errors                        → Winston (future)
Monitor performance               → New Relic (future)
Deploy to cloud                   → Docker + Railway/Render
```

---

This architecture ensures:

- **Scalability**: Stateless server, database indexing, horizontal scaling ready
- **Security**: Multiple layers, JWT auth, input validation, rate limiting
- **Performance**: Optimized queries, caching, pagination, CDN ready
- **Maintainability**: MVC pattern, separated concerns, clear dependencies
- **Reliability**: Error handling, graceful shutdown, health checks
