// Frontend logic: modern UI, SweetAlert2 popups, Chart.js integration
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("resultForm");
  const heroForm = document.getElementById("heroInlineForm");
  const pinInput = document.getElementById("pin");
  const pinHero = document.getElementById("pinHero");
  const submitBtn = document.getElementById("submitBtn");
  const resultDiv = document.getElementById("result");
  const resultContainer = document.getElementById("resultContainer");
  const graphSection = document.getElementById("graphSection");
  const sgpaCanvas = document.getElementById("sgpaChart");
  const downloadPdfBtn = document.getElementById("downloadPdfBtn");
  const semesterFilter = document.getElementById("semesterFilter");

  let currentPin = null;
  let sgpaChart = null;

  const PIN_REGEX = /^[0-9A-Z]{10}$/;

  function toUpperPIN(v) {
    return String(v || "").toUpperCase();
  }

  function showLoading(state) {
    // simple in-button spinner
    submitBtn.disabled = state;
    submitBtn.textContent = state ? "Fetching..." : "Get Result";
  }

  function showError(title, text) {
    if (window.Swal) {
      Swal.fire({ icon: "error", title, text, confirmButtonColor: "#2563EB" });
    } else {
      alert(text);
    }
  }

  function renderResult(data) {
    if (!data) return;
    const d = data;
    currentPin = d.pin || currentPin;
    const name = d.studentName || d.name || "N/A";

    let status = "PASS";
    if (d.failedCount && Number(d.failedCount) > 0) status = "FAIL";
    if (!Array.isArray(d.semesters) || d.semesters.length === 0)
      status = "WITHHELD";

    let html = `<div class="result-card">
      <div class="d-flex justify-content-between align-items-start mb-3">
        <div>
          <h4 class="mb-0">${name}</h4>
          <small class="text-muted">PIN: ${d.pin || ""} &nbsp; ${d.rollNumber ? "• Roll: " + d.rollNumber : ""}</small>
        </div>
        <div class="text-end">
          <div class="status-badge ${status === "PASS" ? "pass" : "fail"}">${status}</div>
          <div class="mt-2 text-muted small">Searched: ${new Date(d.scrapedAt || d.createdAt || Date.now()).toLocaleString()}</div>
        </div>
      </div>

      <div class="result-summary mb-3">
        <div><strong>Semesters:</strong> ${d.totalSemesters || (d.semesters && d.semesters.length) || 0}</div>
        <div><strong>Current SGPA:</strong> ${d.overallSGPA || (d.semesters && d.semesters[0] && d.semesters[0].sgpa) || "N/A"}</div>
        <div><strong>CGPA:</strong> ${d.overallCGPA || (d.semesters && d.semesters[0] && d.semesters[0].cgpa) || "N/A"}</div>
      </div>

      <div>
        ${(d.semesters || [])
          .map((sem) => {
            const tableRows = (sem.subjects || [])
              .map(
                (sub) =>
                  `<tr><td>${sub.subjectCode || ""}</td><td>${sub.subjectName || ""}</td><td>${sub.grade || ""}</td><td>${sub.gradePoint || sub.total || ""}</td><td>${sub.credit || sub.credits || ""}</td></tr>`,
              )
              .join("");
            return `<div class="mb-3"><h6 class="mb-2">Semester ${sem.semester || ""} <small class="text-muted">SGPA: ${sem.sgpa || ""} • CGPA: ${sem.cgpa || ""}</small></h6><div class="table-responsive"><table class="table table-sm"><thead><tr><th>Code</th><th>Subject</th><th>Grade</th><th>GP</th><th>Credit</th></tr></thead><tbody>${tableRows}</tbody></table></div></div>`;
          })
          .join("")}
      </div>
    </div>`;

    resultDiv.innerHTML = html;
    resultContainer.style.display = "block";
    graphSection.style.display = "block";
  }

  function buildChart(semesters) {
    if (!sgpaCanvas) return;
    const labels = (semesters || []).map((s) => s.semester || "");
    const data = (semesters || []).map((s) =>
      parseFloat(String(s.sgpa || "") || NaN),
    );

    // Destroy existing chart to prevent duplicates
    if (sgpaChart) {
      try {
        sgpaChart.destroy();
      } catch (e) {}
      sgpaChart = null;
    }

    const ctx = sgpaCanvas.getContext("2d");
    const gradient = ctx.createLinearGradient(0, 0, 0, 200);
    gradient.addColorStop(0, "rgba(37,99,235,0.28)");
    gradient.addColorStop(1, "rgba(37,99,235,0.02)");

    sgpaChart = new Chart(ctx, {
      type: "line",
      data: {
        labels,
        datasets: [
          {
            label: "SGPA",
            data,
            borderColor: "rgba(37,99,235,1)",
            backgroundColor: gradient,
            fill: true,
            tension: 0.35,
            pointRadius: 5,
            pointBackgroundColor: "#fff",
            pointBorderColor: "rgba(37,99,235,1)",
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          tooltip: { enabled: true },
          legend: { display: false },
          title: { display: true, text: "Semester-wise SGPA Performance" },
        },
        scales: { y: { beginAtZero: true, suggestedMax: 10 } },
      },
    });
  }

  async function fetchResult(pin) {
    if (!pin) return showError("Invalid PIN", "Please provide a PIN.");
    const up = toUpperPIN(pin);
    if (!PIN_REGEX.test(up))
      return showError(
        "Invalid PIN",
        "PIN must be 10 characters (digits and uppercase letters).",
      );

    showLoading(true);

    try {
      const res = await fetch("/api/v1/result", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pin: up }),
      });
      const json = await res.json();
      if (!res.ok || json.success === false) {
        const msg = (json && json.message) || "Failed to fetch result.";
        return showError("Result Not Found", msg);
      }

      const payload = json.data;
      renderResult(payload);
      buildChart(payload.semesters || []);

      // populate semester filter
      semesterFilter.innerHTML =
        '<option value="all">All Semesters</option>' +
        (payload.semesters || [])
          .map(
            (s, i) =>
              `<option value="${i}">Semester ${s.semester || i + 1}</option>`,
          )
          .join("");

      // wire download
      downloadPdfBtn.href = `/api/v1/result/${payload.pin}/download-pdf`;
      downloadPdfBtn.setAttribute("download", `Result_${payload.pin}.pdf`);
    } catch (err) {
      console.error(err);
      showError("Server Error", "Failed to fetch result. Try again later.");
    } finally {
      showLoading(false);
    }
  }

  // Form submission handlers
  if (form)
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      fetchResult(pinInput.value);
    });
  if (heroForm)
    heroForm.addEventListener("submit", (e) => {
      e.preventDefault();
      fetchResult(pinHero.value);
    });

  // Auto-uppercase inputs
  [pinInput, pinHero].forEach((inp) => {
    if (!inp) return;
    inp.addEventListener("input", (e) => {
      e.target.value = toUpperPIN(e.target.value);
    });
    inp.addEventListener("keyup", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        fetchResult(e.target.value);
      }
    });
  });

  // semester filter change
  if (semesterFilter)
    semesterFilter.addEventListener("change", function () {
      const val = this.value;
      if (val === "all") buildChart(window.lastSemesters || []);
      else {
        const idx = Number(val);
        const sem = (window.lastSemesters || [])[idx];
        if (sem) buildChart([sem]);
      }
    });

  // Keep last semesters globally for filter
  const origBuildChart = buildChart;
  buildChart = function (semesters) {
    window.lastSemesters = semesters || [];
    origBuildChart(semesters);
  };
});
