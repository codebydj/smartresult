const scrapeResult = require("../services/scraperService");

exports.getResult = async (req, res) => {
    const { pin } = req.body;

    if (!pin) {
        return res.status(400).json({ error: "PIN is required" });
    }

    const result = await scrapeResult(pin);

    res.json(result);
};