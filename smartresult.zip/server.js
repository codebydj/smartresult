const express = require("express");
const { getResult } = require("./services/scraperService");

const app = express();

app.use(express.static("public"));

app.get("/result", async (req, res) => {
  const { pin, semester } = req.query;

  if (!pin) {
    return res.status(400).json({ error: "PIN is required" });
  }

  try {
    const data = await getResult(pin, semester);
    res.json(data);
  } catch (err) {
    console.error("Error:", err);
    res.status(500).json({ error: "Failed to fetch result" });
  }
});

app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});