async function getResult() {
  const pin = document.getElementById("pin").value;
  const semester = document.getElementById("semester").value;

  const response = await fetch(
    `http://localhost:3000/result?pin=${pin}&semester=${semester}`
  );

  const data = await response.json();

  const resultDiv = document.getElementById("result");

  if (!resultDiv) {
    console.error("Result div not found");
    return;
  }

  if (data.error) {
    resultDiv.innerHTML = `<p style="color:red">${data.error}</p>`;
  } else {
    resultDiv.innerHTML = `
      <h3>Result Details</h3>
      <p><strong>Name:</strong> ${data.name}</p>
      <p><strong>Semester:</strong> ${data.semester}</p>
      <p><strong>SGPA:</strong> ${data.sgpa}</p>
      <p><strong>CGPA:</strong> ${data.cgpa}</p>
    `;
  }
}