const puppeteer = require("puppeteer");

async function getResult(pin, semester) {
  const browser = await puppeteer.launch({ headless: false });

  try {
    const page = await browser.newPage();

    await page.goto("https://www.student.apamaravathi.in/mymarks.php", {
      waitUntil: "networkidle2",
    });

    await page.waitForSelector('input[name="rno"]');

    await page.type('input[name="rno"]', pin);

    await Promise.all([
      page.click('input[type="submit"]'),
      page.waitForNavigation({ waitUntil: "networkidle2" }),
    ]);

    await page.waitForSelector("table");

    const data = await page.evaluate(() => {
      const bodyText = document.body.innerText;

      const nameMatch = bodyText.match(/Name\s*:\s*(.*)/);
      const semMatch = bodyText.match(/Semester\s*:\s*(\d+)/);
      const sgpaMatch = bodyText.match(/SGPA\s*:\s*([\d.]+)/);
      const cgpaMatch = bodyText.match(/CGPA\s*:\s*([\d.]+)/);

      return {
        name: nameMatch ? nameMatch[1].trim() : "",
        semester: semMatch ? semMatch[1] : "",
        sgpa: sgpaMatch ? sgpaMatch[1] : "",
        cgpa: cgpaMatch ? cgpaMatch[1] : "",
      };
    });

    await browser.close();
    return data;

  } catch (err) {
    await browser.close();
    throw err;
  }
}

module.exports = { getResult };